define([],function(){
    var Country = (function(){
        function Country(name){
            this.name = name;
        }
        return Country;
    })();
    return Country;
});