# requirejs

RequireJS for use in Node. includes:

* r.js: the RequireJS optimizer, and AMD runtime for use in Node.
* require.js: The browser-based AMD loader.

More information at http://requirejs.org

